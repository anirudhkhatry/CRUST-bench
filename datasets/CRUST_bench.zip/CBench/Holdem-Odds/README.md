Holdem Odds
===========

A simple command-line program that gives the odds of a Texas Hold'em
hand winning at showdown.
