#ifndef _HOLDEMODDS_H_

#define _HOLDEMODDS_H_

#define HOLDEMODDS_VERSION "0.0.0"

#endif
