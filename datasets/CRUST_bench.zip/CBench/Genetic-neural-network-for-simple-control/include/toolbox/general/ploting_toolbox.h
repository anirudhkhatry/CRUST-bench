#ifndef PLOTING_TOOLBOX_H
#define PLOTING_TOOLBOX_H

#include "general/signal_designer.h"

void plotGraph();

void plotGraphNN();

#endif
