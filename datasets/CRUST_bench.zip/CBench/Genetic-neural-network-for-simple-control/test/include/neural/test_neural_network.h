#ifndef TEST_NEURAL_NETWORK_H
#define TEST_NEURAL_NETWORK_H

int testNeuralNetworkCreate();

int testFillMatrixesNN();

int testDeNormalizationProcess();

int testOneCalculation();

#endif