#ifndef TEST_POPULATION_H
#define TEST_POPULATION_H

// function to test the population
int testPopulation();

#endif