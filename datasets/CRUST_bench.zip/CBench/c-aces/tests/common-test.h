#ifndef COMMON_TEST_H
#define COMMON_TEST_H

#ifdef __cplusplus
extern "C" {
#endif

int run_common_tests();

#ifdef __cplusplus
}
#endif

#endif
