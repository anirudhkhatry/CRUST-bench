
0.1.2 / 2014-10-13
==================

  * fs_fnread: cut buffer using actual read size
  * Be compatible with a C++ compiler

0.1.1 / 2014-06-26
==================

 * Makefile: Build with `__STRICT_ANSI__`
 * Windows fix

0.1.0 / 2014-02-18 
==================

 * Windows port
 * fix install/uninstall targets
 * build: create libfs.a and install/uninstall targets
 * Create test suite
 * fix last-line \n bug.
 * Fix name in package.json
 * Fix memory leaks
 * add `stdio.h` to prevent compilation failures
 * add a minimal travis conf
 * cleanup whitespace in fs.c
 * remove unnecessary test
 * Use const for char pointer parameters.
 * fixed failing test
 * Move implementation to fs.c.
 * close file descriptors
 * add `fs_exists(path)`
 * mkdir/rmdir
 * added package.json
