Printf'in warning veren durumları tam eşleşmeyebilir
